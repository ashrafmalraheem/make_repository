AUTHOR: Kylie Humble
PROJECT: This program includes a couple of functions that can analyze an array of unsigned
	 char data items and report analytics on the maximum, minimum, mean, and median of 
	 a given data set. In addition, it reorders the the data set from large to small. 
	 All statistics are rounded to the nearest integer. After analysis and sorting is 
	 done, it will print that data to the screen in a, nicely, formatted presentation.
