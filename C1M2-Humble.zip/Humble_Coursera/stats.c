/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file: stats.c
 * @brief description: This application performs statistical
 * 		       analysis on a dataset
 *
 * This program includes a couple of functions that can analyze an array of unsigned
 * char data items and report analytics on the maximum, minimum, mean, and median of 
 * a given data set. In addition, it reorders the data set from large to small. 
 * All statistics are rounded to the nearest integer. After analysis and sorting is 
 * done, it will print that data to the screen in nicely formatted presentation.
 *
 * @author: Kylie Humble
 * @date: 10/10/2018
 */

#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include "stats.h"

void print_array(unsigned char test[], unsigned int SIZE)
{
    printf("Array:\n");

    for (int i = 0; i < SIZE; i++)
        printf("%d ", test[i]);
    printf("\n");
}

void sort_array(unsigned char test[], unsigned int SIZE)
{
    int temp;
    unsigned char * sorted_array = malloc(SIZE * sizeof(unsigned char));
    
    for (int i = 0; i < SIZE; i++)
    {
	for (int j = 0; j < SIZE; j++)
	{
	    if (test[j] < test[i])
            {
		temp = test[i];
		test[i] = test[j];
		test[j] = temp;
	    }
	}
    }

    printf("Sorted Array (from largest to smallest):\n");
    for (int k = 0; k < SIZE; k++)
        printf("%d ", test[k]);
    printf("\n");    
}

unsigned int find_median(unsigned char arr[])
{
    int val1 = arr[19],
        val2 = arr[20];
    unsigned int median = (arr[19] + arr[20]) / 2;

    return median; 
}

unsigned int find_mean(unsigned char arr[], unsigned int SIZE)
{
    unsigned int mean;
    int sum = 0;

    for (int i = 0; i < SIZE; i++)
        sum = sum + arr[i];
    mean = sum / SIZE;

    return mean;
}

unsigned int find_maximum(unsigned char arr[])
{
    unsigned int maximum = arr[0];
    return maximum;
}

unsigned int find_minimum(unsigned char arr[])
{
    unsigned int minimum = arr[39];
    return minimum;
}

void print_statistics(unsigned int min, unsigned int max, unsigned int mean, unsigned int median)
{
    printf("Minimum: %d Maximum: %d Mean: %d Median: %d\n", min, max, mean, median);
}

/* Size of the Data Set */
#define SIZE (40)

void main() 
{ 
	unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,
				      6, 114, 88,   45,  76, 123,  87,  25,  23, 200, 122, 150, 90,   92,
				     87, 177, 244, 201,   6,  12,  60,   8,   2,   5,  67, 7,  87, 250, 230,
				     99,   3, 100,  90};

    /* Other Variable Declarations Go Here */
    unsigned char * sorted_array;
    unsigned int median, mean, maximum, minimum;

    /* Statistics and Printing Functions Go Here */
    print_array(test, SIZE);
    sort_array(test, SIZE);
    median = find_median(test);
    mean = find_mean(test, SIZE);
    maximum = find_maximum(test);
    minimum = find_minimum(test);
    print_statistics(minimum, maximum, mean, median);
}
