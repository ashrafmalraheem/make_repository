/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief This application performs statistical analysis on a dataset
 *
 * This program includes a couple of functions that can analyze an array of
 * unsigned char data items and reports analytics on the maximum, minimum, 
 * mean, and median of a given data set. In addition, it reorders the data set 
 * from large to small. All statistics are rounded to the nearest integer. 
 * After analysis and sorting is done, it will print that data to the screen 
 * nicely formatted presentation.
 *
 * @author Kylie Humble
 * @date 10/10/2018
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief Print the array to the screen
 *
 * Given an array of data and a length, this function prints the array to the 
 * screen
 *
 * @param unsigned char test[] An unsigned character pointer to an n-element data array
 * @param unsigned int SIZE An unsigned integer as the size of the array
 */
void print_array(unsigned char test[], unsigned int SIZE);//

/**
 * @brief Sorts the array from smallest to largest
 *
 * Given an array of data and a length, sorts the array from largest to smallest.
 * (The zeroth element should be the largest value, and the last element (n-1) should 
 * be the smallest value.)
 *
 * @param unsigned char test[] An unsigned character pointer to an n-element data array
 * @param unsigned int SIZE An unsigned integer as the size of the array
 */
void sort_array(unsigned char test[], unsigned int SIZE);

/**
 * @brief Calculates the median value of an array 
 *
 * Given an array of data and a length, this function returns the median value
 *
 * @param unsigned char test[] An unsigned character pointer to an n-element data array
 *
 * @return The median value of an array of type unsigned int
 */
unsigned int find_median(unsigned char arr[]);//

/**
 * @brief Calculates the mean value of an array 
 *
 * Given an array of data and a length, this function returns the mean value
 *
 * @param unsigned char test[] An unsigned character pointer to an n-element data array
 * @param unsigned int SIZE An unsigned integer as the size of the array
 *
 * @return The mean value of an array of type unsigned int
 */
unsigned int find_mean(unsigned char arr[], unsigned int SIZE);

/**
 * @brief Reveals the maximum value of an array 
 *
 * Given an array of data and a length, this function returns the maximum value
 *
 * @param unsigned char test[] An unsigned character pointer to an n-element data array
 * @param unsigned int SIZE An unsigned integer as the size of the array
 *
 * @return The maximum value of an array of type unsigned int
 */
unsigned int find_maximum(unsigned char arr[]);//

/**
 * @brief Reveals the minimum value of an array 
 *
 * Given an array of data and a length, this function returns the minimum value
 *
 * @param unsigned char test[] An unsigned character pointer to an n-element data array
 * @param unsigned int SIZE An unsigned integer as the size of the array
 *
 * @return The minimum value of an array of type unsigned int
 */
unsigned int find_minimum(unsigned char arr[]);

/**
 * @brief Prints the statistics of an array
 *
 * This function prints the statistics of an array including the minimum, maximum,
 * mean, and median values
 *
 * @param unsigned int minimun An unsigned integer as the minimum value of the array
 * @param unsigned int maximum An unsigned integer as the maximum value of the array
 * @param unsigned int mean An unsigned integer as the mean of the array
 * @param unsigned int median An unsigned integer as the median of the array
 */
void print_statistics(unsigned int min, unsigned int max, unsigned int mean, unsigned int median);

#endif /* __STATS_H__ */
